
	function searchformfocus(x) {
	
		x.style.background = "white";
	}
	
	function ShowPassword(item, credential, owner){
		
		//Getting the ID of the "a" element who called the function . Id is autoincremental (check viewItem.php)
		//alert($(event.target)[0].id);
		var IdTargetElement = $(event.target)[0].id;
		
		
		Swal.fire({
		  title: 'View password for '+item.toUpperCase()+' ?',
		  html: "An email will be sent to: <strong>"+owner+"</strong><p>Please choose the reason:</p><select><option value='StandBy duty'>StandBy duty</option><option value='Debug'>Debug</option><option value='Maintenance'>Maintenance</option>",
		  icon: 'warning',
		  showCancelButton: true,
		  confirmButtonColor: '#3085d6',
		  cancelButtonColor: '#d33',
		  confirmButtonText: 'Got it!'
		}).then((result) => {
			
			if (result.value) {
			//alert("clicked");
				$.ajax(
						{
							type: "POST",
							url: '../item/ReadPwd.php',
							dataType: 'json',
							data: {
								item: item,
								credential: credential,
							},
							error: function (result) {
								alert(result.responseText);
							},
							success: function (result) {
								if (result['status'] == true) {
								
								$("#"+IdTargetElement).html("<span class='show-item-password'>"+result['password']+"</span>");	
								$(".show-item-password").css({"text-decoration":"none" , "font-weight":"bold"});
								$('a[id="'+IdTargetElement+'"]').contents().unwrap();

								}
								else {
									alert(result['message']);
								}
							}
						});
			} 
 
			});	//end Swal call
	} //end function ShowPassword

	

	
	function Remove(id , name){
		//alert(name);
		
		Swal.fire({
				  title: 'Delete '+name.toUpperCase()+' ?',
				  text: "You won't be able to revert this!",
				  icon: 'warning',
				  showCancelButton: true,
				  confirmButtonColor: '#3085d6',
				  cancelButtonColor: '#d33',
				  confirmButtonText: 'Yes, delete it!'
				}).then((result) => {
				  if (result.value) {
				  $.ajax(
						{
							type: "POST",
							url: './item/delete.php',
							dataType: 'json',
							data: {
								id: id,
								name: name,
							},
							error: function (result) {
								alert(result.responseText);
							},
							success: function (result) {
								if (result['status'] == true) {
								
									Swal.fire({
											  title: 'Deleted!',
											  text: 'The item has been deleted.',
											  icon: 'success',
											  showConfirmButton: false,
											  timer: 2000,
											  onClose: function(){ window.location.href = './home.php';},
												});
								}
								else {
									alert(result['message']);
								}
							}
						});
				}
				});
} // end function Remove


	function RemoveFromViewItem(id , name){
		//alert(name);
		
		Swal.fire({
				  title: 'Delete '+name.toUpperCase()+' ?',
				  text: "You won't be able to revert this!",
				  icon: 'warning',
				  showCancelButton: true,
				  confirmButtonColor: '#3085d6',
				  cancelButtonColor: '#d33',
				  confirmButtonText: 'Yes, delete it!'
				}).then((result) => {
				  if (result.value) {
				  $.ajax(
						{
							type: "POST",
							url: 'delete.php',
							dataType: 'json',
							data: {
								id: id,
								name: name,
							},
							error: function (result) {
								alert(result.responseText);
							},
							success: function (result) {
								if (result['status'] == true) {
								
									Swal.fire({
											  title: 'Deleted!',
											  text: 'The item has been deleted.',
											  icon: 'success',
											  showConfirmButton: false,
											  timer: 2000,
											  onClose: function(){ window.location.href = '../home.php';},
												});
								}
								else {
									alert(result['message']);
								}
							}
						});
				}
				});
} //end function RemoveFromViewItem



	function RemovePwd(name, credential){
		//alert(name);
		
		Swal.fire({
				  title: 'Delete '+credential.toUpperCase()+' ?',
				  text: "You won't be able to revert this!",
				  icon: 'warning',
				  showCancelButton: true,
				  confirmButtonColor: '#3085d6',
				  cancelButtonColor: '#d33',
				  confirmButtonText: 'Yes, delete it!'
				}).then((result) => {
				  if (result.value) {
				  $.ajax(
						{
							type: "POST",
							url: 'deletePwd.php',
							dataType: 'json',
							data: {
								name: name,
								credential: credential,
							},
							error: function (result) {
								alert(result.responseText);
							},
							success: function (result) {
								
								if (result['status'] == true) {
								
									Swal.fire({
											  title: 'Deleted!',
											  text: 'The credential has been deleted.',
											  icon: 'success',
											  showConfirmButton: false,
											  timer: 2000,
											  onClose: function(){ location.reload();},
												});
								}
								else {
									alert(result['message']);
								}
							}
						});
				}
				});
} // end function RemovePWD
	
	
  function searchItem() {
	
	var text = $("#search-form").val();
	//alert('ciao');
	$.ajax(
        {	
            type: "get",
            url: './item/search.php',
            dataType: 'json',
            data: {
					text2search: text,
            },
            error: function (valore_di_ritorno) {
					
					alert("No item searched")
					//alert(valore_di_ritorno.responseText);
			},
			
            success: function (data) {
			
            if (data['status'] == false) {    
					
					var response="<table id='table-item'>"+
						"<thead>"+
						"<tr>"+
                        "<th>Name</th>"+
                        "<th>State</th>"+
                        "<th>Purpose</th>"+
                        "<th>Location</th>"+
                        "<th>Platform</th>"+
                        "<th>Type</th>"+
						"<th>Ip Address</th>"+
						"<th>Version</th>"+
						"<th>Owner</th>"+
						"</tr>"+
						"</thead>";
					response += "<tr><td colspan='8' style='padding:10px;'>No suggestion</td></tr>";
					//$("#table-item").html(response);
				}
				
			else{
					var response="<table id='table-item'>"+
						"<thead>"+
						"<tr>"+
                        "<th>Name</th>"+
                        "<th>State</th>"+
                        "<th>Purpose</th>"+
                        "<th>Location</th>"+
                        "<th>Platform</th>"+
                        "<th>Type</th>"+
						"<th>Ip Address</th>"+
						"<th>Version</th>"+
						"<th>Owner</th>"+
						//"<th>Network</th>"+
						"</tr>"+
						"</thead>";
						
					for(var item in data){
						
						response += "<tr>"+
						"<td style='padding:10px;'><a href='item/viewItem.php?id="+data[item].id+"' class='viewItem' title='View details' >"+data[item].name.toUpperCase()+"</a></td>"+
						"<td>"+data[item].state+"</td>"+
						"<td>"+data[item].purpose+"</td>"+
						"<td>"+data[item].location+"</td>"+
						"<td>"+data[item].platform+"</td>"+
						"<td>"+data[item].type+"</td>"+
						"<td>"+data[item].ipaddress+"</td>"+
						"<td>"+data[item].version+"</td>"+
						"<td>"+data[item].owner+"</td>"+
						//"<td>"+data[item].network+"</td>"+
						"<td class='icon-control'><a class='item-icon' title='Edit Item' href='item/update.php?id="+data[item].id+"'><img src='img/edit-item.png'></a><a class='item-icon' title='Delete Item' href='#' onClick=Remove('"+data[item].id+"','"+data[item].name+"')><img src='img/delete-item.png'></a></td>"+
						"</tr>";
				
					
					}
				}
					$(" #table-item").html(response);
					$( "#table-item th" ).css ("background-color", "#C1E3F0");
					$( "#table-item tr:odd" ).css( "background-color", "#F0F0F0" );
					$( "#table-item tr:even" ).css( "background-color", "#fff" );
					
				window.location.href = '#';
            }
	});
} //end function searchItem
	



function searchItemFromView() {
	
	var text = $("#search-form").val();
	
	$.ajax(
        {	
            type: "get",
            url: 'search.php',
            dataType: 'json',
            data: {
					text2search: text,
            },
            error: function (valore_di_ritorno) {
					
					alert("No item searched")
					//alert(valore_di_ritorno.responseText);
			},
			
            success: function (data) {
			
            if (data['status'] == false) {    
					
					var response="<h3>Here goes a subtitle</h3>"+
						"<div id='table-container-smooth'>"+
						"<table id='table-item'>"+
						"<thead>"+
						"<tr>"+
                        "<th>Name</th>"+
                        "<th>State</th>"+
                        "<th>Purpose</th>"+
                        "<th>Location</th>"+
                        "<th>Platform</th>"+
                        "<th>Type</th>"+
						"<th>Ip Address</th>"+
						"<th>Version</th>"+
						"<th>Owner</th>"+
						"</tr>"+
						"</thead>";
					response += "<tr><td colspan='8' style='padding:10px;'>No suggestion</td></tr>";
					//$("#table-item").html(response);
				}
				
			else{
					var response= "<h3>Here goes a subtitle</h3>"+
						"<div id='table-container-smooth'>"+
						"<table id='table-item'>"+
						"<thead>"+
						"<tr>"+
                        "<th>Name</th>"+
                        "<th>State</th>"+
                        "<th>Purpose</th>"+
                        "<th>Location</th>"+
                        "<th>Platform</th>"+
                        "<th>Type</th>"+
						"<th>Ip Address</th>"+
						"<th>Version</th>"+
						"<th>Owner</th>"+
						//"<th>Network</th>"+
						"</tr>"+
						"</thead>";
						
					for(var item in data){
						
						response += "<tr>"+
						"<td style='padding:10px;'><a href='viewItem.php?id="+data[item].id+"' class='viewItem' title='View details' >"+data[item].name.toUpperCase()+"</a></td>"+
						"<td>"+data[item].state+"</td>"+
						"<td>"+data[item].purpose+"</td>"+
						"<td>"+data[item].location+"</td>"+
						"<td>"+data[item].platform+"</td>"+
						"<td>"+data[item].type+"</td>"+
						"<td>"+data[item].ipaddress+"</td>"+
						"<td>"+data[item].version+"</td>"+
						"<td>"+data[item].owner+"</td>"+
						//"<td>"+data[item].network+"</td>"+
						"<td class='icon-control'><a class='item-icon' title='Edit Item' href='update.php?id="+data[item].id+"'><img src='../img/edit-item.png'></a><a class='item-icon' title='Delete Item' href='#' onClick=RemoveFromViewItem('"+data[item].id+"','"+data[item].name+"')><img src='../img/delete-item.png'></a></td>"+
						"</tr>";
				
					
					}
				}
					response += "</table></div>";
					$( "#table-container-view-item").html(response);
					$( "#table-container-view-item th" ).css ("background-color", "#C1E3F0")
					$( "#table-container-view-item tr:odd" ).css( "background-color", "#F0F0F0" );
					$( "#table-container-view-item tr:even" ).css( "background-color", "#fff" );
				
				window.location.href = '#';
            }
	});
} //end function searchItemFromView



	
	
	function hasWhiteSpace(text) 
	{
		var check = text.split(' ');
		//alert(check);
		if(check == '' || check.length > 1)
		{
			Swal.fire({
						  title: 'Error!',
						   html:
								'Field <b>Name</b>, ' +
								'cannot be blank or contain any space ' ,
						  icon: 'error',
						  onClose: function(){ window.location.href = '#';},
					});
			return false;
		}

		return true;
} //end function hasWhiteSpace
	
	
	
	function AddItem(){
	
	var name = $("#input-name").val();
	
	if(hasWhiteSpace(name)){

		$.ajax(
			{	
				type: "POST",
				url: '../api/create.php',
				dataType: 'json',
				data: {
						name: $("#input-name").val(),
						state: $("#input-state").val(),
						purpose: $("#input-purpose").val(),
						location: $("#input-location").val(),
						platform:  $("#input-platform").val(),
						power:  $("#input-power").val(),
						storage: $("#input-storage").val(),
						digiport:  $("#input-digi").val(),
						hostnameAlias: $("#input-alias").val(),
						type: $("#input-type").val(),
						ipaddress: $("#input-ipaddress").val(),
						severity: $("#input-severity").val(),
						version: $("#input-version").val(),
						owner: $("#input-owner").val(),
						network: $("#input-network").val(),
						comments: $("#input-comments").val(),
						installationDate: $("#input-installation-date").val(),
						credential: $("#input-credential").val(),
						password: $("#input-password").val(),
						otherInfo: $("#input-other-info").val(),
				},
				error: function (valore_di_ritorno) {
						
						
						alert(valore_di_ritorno.responseText);
				},
				
				success: function (valore_di_ritorno) {
						
						Swal.fire({
									  title: 'Thank you!',
									  text: 'Item successfully added',
									  icon: 'success',
									  showConfirmButton: false,
									  timer: 2000,
									  onClose: function(){ window.location.href = '../home.php';},
									});
				} 
	  
			});
		}
		
		else
		{
			$("#input-name").css("background-color" , "#EDA899");
		}
} //end function AddItem
	
	
	
	function UpdateItem(id){
	
	var name = $("#input-name").val();
	
	if(hasWhiteSpace(name)){

		$.ajax(
			{	
				type: "POST",
				url: '../api/update.php',
				dataType: 'json',
				data: {
						id: id, 
						name: $("#input-name").val(),
						state: $("#input-state").val(),
						purpose: $("#input-purpose").val(),
						location: $("#input-location").val(),
						platform:  $("#input-platform").val(),
						power:  $("#input-power").val(),
						storage: $("#input-storage").val(),
						digiport:  $("#input-digi").val(),
						hostnameAlias: $("#input-alias").val(),
						type: $("#input-type").val(),
						ipaddress: $("#input-ipaddress").val(),
						severity: $("#input-severity").val(),
						version: $("#input-version").val(),
						owner: $("#input-owner").val(),
						network: $("#input-network").val(),
						comments: $("#input-comments").val(),
						installationDate: $("#input-installation-date").val(),
						credential: $("#input-credential").val(),
						password: $("#input-password").val(),
						otherInfo: $("#input-other-info").val(),
				},
				error: function (valore_di_ritorno) {
						
						//alert('errore');
						alert(valore_di_ritorno.responseText);
				},
				
				success: function (valore_di_ritorno) {
						
						Swal.fire({
									  title: 'Thank you!',
									  text: 'Item successfully updated',
									  icon: 'success',
									  showConfirmButton: false,
									  timer: 2000,
									  //onClose: function(){ window.location.href = '../home.php';},
									});
				} 
	  
			});
		}
		
		else
		{
			$("#input-name").css("background-color" , "#EDA899");
		}
} //end function UpdateItem


function AddPwd(name){

	$.ajax(
			{	
				type: "POST",
				url: '../api/addPwd.php',
				dataType: 'json',
				data: {
						name: name,
						credential: $("#new-credential").val(),
						password: $("#new-password").val(),
						otherInfo: $("#new-description").val(),
				},
				error: function (valore_di_ritorno) {
						
						alert(valore_di_ritorno.responseText);
				},
				
				success: function (valore_di_ritorno) {
						
						if(valore_di_ritorno['status'] == true)
						{
						Swal.fire({
									  title: 'Thank you!',
									  text: 'Credential successfully added',
									  icon: 'success',
									  showConfirmButton: false,
									  timer: 2000,
									  onClose: function(){ 
									  
										$(" #main-container-add-pwd").fadeOut('fast');
										//window.location.href = '#';
										location.reload();
									  
										},
									});
						}
						else
						{
						Swal.fire({
									  title: 'Error!',
									  text: 'No credential supplied, please add one',
									  icon: 'error',
									  
									});
						
						}
				} 
	  
			});
}






























	
	 