
	function searchformfocus(x) {
	
		x.style.background = "white";
	}
	
	
	function Remove(id , name){
		//alert(name);
		var result = confirm("Are you sure you want to delete the Item "+name.toUpperCase()+"?"); 
		
		if (result == true) { 
			$.ajax(
			{
				type: "POST",
				url: './item/delete.php',
				dataType: 'json',
				data: {
					id: id
				},
				error: function (result) {
					alert(result.responseText);
				},
				success: function (result) {
					if (result['status'] == true) {
						alert(name.toUpperCase()+" successfully removed!");
						window.location.href = './home.php';
					}
					else {
						alert(result['message']);
					}
				}
			});
		}
	}
	
	
  function searchItem() {
	
	var text = $("#search-form").val();
	
	$.ajax(
        {	
            type: "get",
            url: './item/search.php',
            dataType: 'json',
            data: {
					text2search: text,
            },
            error: function (valore_di_ritorno) {
					
					alert("No item searched")
					//alert(valore_di_ritorno.responseText);
			},
			
            success: function (data) {
			
            if (data['status'] == false) {    
					
					var response="<table id='table-item'>"+
						"<thead>"+
						"<tr>"+
                        "<th>Name</th>"+
                        "<th>State</th>"+
                        "<th>Purpose</th>"+
                        "<th>Location</th>"+
                        "<th>Platform</th>"+
                        "<th>Type</th>"+
						"<th>Ip Address</th>"+
						"<th>Version</th>"+
						"<th>Owner</th>"+
						"</tr>"+
						"</thead>";
					response += "<tr><td colspan='8' style='padding:10px;'>No suggestion</td></tr>";
					$("#table-item").html(response);
				}
				
			else{
					var response="<table id='table-item'>"+
						"<thead>"+
						"<tr>"+
                        "<th>Name</th>"+
                        "<th>State</th>"+
                        "<th>Purpose</th>"+
                        "<th>Location</th>"+
                        "<th>Platform</th>"+
                        "<th>Type</th>"+
						"<th>Ip Address</th>"+
						"<th>Version</th>"+
						"<th>Owner</th>"+
						//"<th>Network</th>"+
						"</tr>"+
						"</thead>";
						
					for(var item in data){
						
						response += "<tr>"+
						"<td style='padding:10px;'>"+data[item].name.toUpperCase()+"</td>"+
						"<td>"+data[item].state+"</td>"+
						"<td>"+data[item].purpose+"</td>"+
						"<td>"+data[item].location+"</td>"+
						"<td>"+data[item].platform+"</td>"+
						"<td>"+data[item].type+"</td>"+
						"<td>"+data[item].ipaddress+"</td>"+
						"<td>"+data[item].version+"</td>"+
						"<td>"+data[item].owner+"</td>"+
						//"<td>"+data[item].network+"</td>"+
						"<td><a class='item-icon' title='Edit Item' href='update.php?id="+data[item].id+"'><img src='img/edit-item.png'></a><a class='item-icon' title='Delete Item' href='#' onClick=Remove('"+data[item].id+"','"+data[item].name+"')><img src='img/delete-item.png'></a></td>"+
						"</tr>";
				
					$("#table-item").html(response);
					}
				}
				
				window.location.href = '#';
            }
	});
}

	function test(){
	
	
	}


	function AddItem(){

		$.ajax(
			{	
				type: "POST",
				url: '../api/create.php',
				dataType: 'json',
				data: {
						name: $("#input-name").val(),
						state: $("#input-state").val(),
						purpose: $("#input-purpose").val(),
						location: $("#input-location").val(),
						platform:  $("#input-platform").val(),
						power:  $("#input-power").val(),
						storage: $("#input-storage").val(),
						digiport:  $("#input-digi").val(),
						hostnameAlias: $("#input-alias").val(),
						type: $("#input-type").val(),
						ipaddress: $("#input-ipaddress").val(),
						severity: $("#input-severity").val(),
						version: $("#input-version").val(),
						owner: $("#input-owner").val(),
						network: $("#input-network").val(),
						comments: $("#input-comments").val(),
						installationDate: $("#input-installation-date").val(),
				},
				error: function (valore_di_ritorno) {
						
						
						alert(valore_di_ritorno.responseText);
				},
				
				success: function (valore_di_ritorno) {
						
						Swal.fire({
									  title: 'Great!',
									  text: 'Item successfully added',
									  icon: 'success',
									  showConfirmButton: false,
									  timer: 2000,
									  onClose: function(){ window.location.href = '../home.php';},
									});
						
				} 
	  
			});
			
		//test();	
	}
	 