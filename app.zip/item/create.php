<script src="../js/jquery.js"></script>
<script src="../js/functions.js"></script>
<script src="../sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="../sweetalert2.min.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css">


<div id="wrapper">
	<div id="header-content">
		<div id="header-title-content"><a class="header-main-title" href="../home.php"><header>EMEA IT Hardware List</header></a></div>
	</div>
	<div id="menu">
	<div id="user-info">
		<img src="../img/avatar.png" class="img-circle">
		<span class="username">EMEA\<?php echo getenv('USERNAME')?></span>
	</div>
	<div id="search-form-content">
		<ul class="ul-menu-search">
			<li class="li-menu-search"><input type="text" placeholder="Search..." id="search-form" onFocus="searchformfocus(this);"></li>
			<li class="li-menu-search"><a href="#" onClick="searchItem();"><img src="../img/search.png" id="search-button"/></a></li>
		</ul>
	</div>
	<div id="submenu">
		<ul class="ul-menu-nav">
			<li class="li-menu-nav"><a href="create.php">Create Item</a></li>
			<li class="li-menu-nav">Multiple edit</li>
		</ul>
	</div>
	</div>
	
	<!--End of menu div, on left side-->
	
	<div id="data-content">
		<div id="dashboard-title"><h1><a href="../home.php" class="img-back"><img src="../img/back.png"/></a>EMEA IT Hardware List<small> > Create item</small></h1></div>
		<div id="table-container-create">
		<h3 class="title-add-new-item">Add new item</h3>
				<table class="table-item-create">
						<tr>
							<td class="form-group">
								<span class="form-control">Name</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-name"/>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">State</span>
							</td>
							<td class="form-group">
									<select class="form-control-input" id="input-state">
										<option value="Live">Live</option>
										<option value="Construction">Construction</option>
										<option value="Retired">Retired</option>
									</select>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Purpose</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-purpose"/>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Location</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-location">
									<option value="Lugano">Lugano</option>
									<option value="Paris">Paris</option>
									<option value="Brno">Brno</option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Platform</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-platform">
									<option value="Windows">Windows</option>
									<option value="Linux">Linux</option>
									<option value="VMware">VMware</option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Power connected to</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-power"></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Storage connected to</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-storage"></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Digiport/RM</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-digi"/>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Hostname-alias</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-alias"></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Type</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-type">
									<option value="Server">Server</option>
									<option value="Virtual machine">Virtual machine</option>
									<option value="Access point">Access point</option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Ip Address</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-ipaddress"></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Severity</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-severity">
									<option value="Level A">Level A</option>
									<option value="Level B">Level B</option>
									<option value="Level C">Level C</option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Version</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-version"/>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Owner</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-owner">
									<option value="ownerA@test.com">ownerA@test.com</option>
									<option value="ownerB@test.com">ownerB@test.com</option>
									<option value="ownerC@test.com">ownerC@test.com</option>
								</select>
							</td>
						</tr>	
						<tr>
							<td class="form-group">
								<span class="form-control">Network connected to</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-network"></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Comments</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-comments"></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">Installation date</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-installation-date"/>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">System credential</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-credential"/>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">System password</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-password"/>
							</td>
						</tr>
						<tr>
							<td class="form-group">
								<span class="form-control">System other info</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-other-info"/>
							</td>
						</tr>
						<tr>
							<td colspan="2">
								<input type="button" value="Add item" class="add-item"><input type="button" value="Cancel" class="cancel">
							</td>
						</tr>
				</table>
		</div>
	</div>
</div>




<script>

$( function() {
    $( "#input-installation-date" ).datepicker();
  } );
  
$(".add-item").click(function(){
	AddItem(); 
});

$(".cancel").click(function(){
	window.location.href = '../home.php';
})

$(".form-control-input").focus(function(){

	$(this).css("background-color", "#e5fff3");
})

$(".form-control-input").blur(function(){

	$(this).css("background-color", "white");
})

$( ".table-item-create tr:odd" ).css ("background-color", "#F0F0F0");
$( " .form-control-input").css({"font-size":"18px" , "width":"400px"});

 </script>
