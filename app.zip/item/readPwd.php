<?php
// include object files
include_once '../api/class.php';


$credential2view = new item_with_password();

$itemName = $_POST['item'];
$credential = $_POST['credential'];
//echo $itemName;
//echo $credential;

 
// query hwpassword table

$result = $credential2view->ReadSinglePwd($itemName,$credential );


    // hw array
    $hw_arr=array();
    $hw_arr["item"]=array();
 
    while ($row = mysqli_fetch_array($result)){
		
		//echo $row[3];
		extract($row);
        $item_returned=array(
            "id" => $id,
            "name" => $name,
            "credential" => $credential,
            "password" => $pwd,
            "description" => $description,
			"status" => true,
			
		);
    }
	//echo $item_returned;
    echo json_encode($item_returned);


?>