<?php

include_once '../api/class.php';
$q = $_GET['id'];

$item = new item_with_password();

$result = $item->readItem($q);

while ($view = mysqli_fetch_array($result)){
	extract($view);
	$item_returned = array(
		"id" => $id,
		"name" => $name,
		"state" => $state,
		"purpose" => $purpose,
		"location" => $location,
		"platform" => $os,
		"power" => $power,
		"storage" => $storage,
		"digiport" => $digiport,
		"hostname-alias" => $name_alias,
		"type" => $type,
		"ipaddress" => $ipaddress,
		"severity" => $severity,
		"version" => $version,
		"owner" => $owner,
		"network" => $network,
		"comments" => $comment,
		"installationDate" => $installation_date,
		"creationDate" => $creation_date,
		"creator" => $user_creator,
		"lastUpdateDate" => $last_update_date,
		"lastUpdateUser" => $last_update_user,
	);
};


//Check if hte item has password. If so, prepare the content

	if($result = $item->readallpwd($item_returned['name']))
	{
		$AllCredential = ($result[0]);
		$AllPassword = ($result[1]);
		$AllDescription = ($result[2]);
		$PwdContainer = "<table class='table-view-item-password-container'><thead><th>System Credential</th><th>System Password</th><th>System Description</th></thead>";
		$i = 0;
		foreach($AllCredential as $credential)
		{
			$PwdContainer .= '<tr><td><span class="view-item-credential">'. $credential . '</span></td><td><a href="#" id="ShowPassword'. $i .'" class="view-item-password" onClick="ShowPassword(\''. $item_returned['name'] .'\',\''. $credential .'\',\''. $item_returned['owner'] .'\');" >Show password</a></td><td><span class="view-item-description">'. $AllDescription[$i]. '</span></td><td><a href="#" onClick="RemovePwd(\''. $item_returned['name'] .'\',\''. $credential .'\')";><img src = "../img/delete-item.png"></a></td></tr>';
			$i = $i+1;
		}
		$PwdContainer .= '</table>';
	}
	if(empty($AllCredential))
	{
		$PwdContainer = "<table class='table-view-item-password-container'><thead><th>System Credential</th><th>System Password</th><th>System Description</th></thead>";
		$PwdContainer .= '<tr><td colspan="3" class="view-item-password-no-credential">No credential created yet</td>';
		$PwdContainer .= '</table>';
	}

?>

<script src="../js/jquery.js"></script>
<script src="../js/functions.js"></script>
<script src="../sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="../sweetalert2.min.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css">


<div id="wrapper">
	<div id="header-content">
		<div id="header-title-content"><a class="header-main-title" href="../home.php"><header>EMEA IT Hardware List</header></a></div>
	</div>
	<div id="menu">
	<div id="user-info">
		<img src="../img/avatar.png" class="img-circle">
		<span class="username">EMEA\<?php echo getenv('USERNAME')?></span>
	</div>
	<div id="search-form-content">
		<ul class="ul-menu-search">
			<li class="li-menu-search"><input type="text" placeholder="Search..." id="search-form" onFocus="searchformfocus(this);"></li>
			<li class="li-menu-search"><a href="#" onClick="searchItemFromView();"><img src="../img/search.png" id="search-button"/></a></li>
		</ul>
	</div>
	<div id="submenu">
		<ul class="ul-menu-nav">
			<li class="li-menu-nav"><a href="../item/create.php">Create Item</a></li>
			<li class="li-menu-nav">Multiple edit</li>
		</ul>
	</div>
	</div>
	
	<!--End of menu div, on left side-->
	
	<div id="data-content">
		<div id="dashboard-title"><h1><a href="../home.php" class="img-back"><img src="../img/back.png"/></a>EMEA IT Hardware List<small> > Edit item</small></h1></div>
		<div id="table-container-view-item">
		<h3 class="title-view-item">Details item: <?php echo (strtoupper ($item_returned['name']) ); ?> </h3>
		
		<table class="main-table-item-view">
			<tr>
				<td>
					<table class="table-item-view-data-content-left">
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Name</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-name" value="<?php echo $item_returned['name']?>" />
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">State</span>
							</td>
							<td class="form-group">
									<select class="form-control-input" id="input-state">
										<option value="<?php echo $item_returned['state']?>"><?php echo $item_returned['state']?>
										<option value="Live">Live</option>
										<option value="Construction">Construction</option>
										<option value="Retired">Retired</option>
									</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Purpose</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-purpose" value="<?php echo $item_returned['purpose']?>" />
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Location</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-location">
									<option value="<?php echo $item_returned['location']?>"><?php echo $item_returned['location']?>
									<option value="Lugano">Lugano</option>
									<option value="Paris">Paris</option>
									<option value="Brno">Brno</option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Platform</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-platform">
									<option value="<?php echo $item_returned['platform']?>"><?php echo $item_returned['platform']?>
									<option value="Windows">Windows</option>
									<option value="Linux">Linux</option>
									<option value="VMware">VMware</option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Power connected to</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-power" ><?php echo $item_returned['power']?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Storage connected to</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-storage" ><?php echo $item_returned['storage']?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Digiport/RM</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-digi" value="<?php echo $item_returned['digiport']?>"/>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Hostname-alias</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-alias"><?php echo $item_returned['hostname-alias']?></textarea>
							</td>
						</tr>
					</table>
				</td> <!--Close first TD of the table-item-view-->
				
				<td> <!--Open second TD of the table-item-view-->
					<table class="table-item-view-data-content-right">
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Type</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-type">
									<option value="<?php echo $item_returned['type']?>"><?php echo $item_returned['type']?>
									<option value="Server">Server</option>
									<option value="Virtual machine">Virtual machine</option>
									<option value="Access point">Access point</option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Ip Address</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-ipaddress"><?php echo $item_returned['ipaddress']?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Severity</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-severity">
									<option value="<?php echo $item_returned['severity']?>"><?php echo $item_returned['severity']?>
									<option value="Level A">Level A</option>
									<option value="Level B">Level B</option>
									<option value="Level C">Level C</option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Version</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-version" value="<?php echo $item_returned['version']?>"/>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Owner</span>
							</td>
							<td class="form-group">
								<select class="form-control-input" id="input-owner">
									<option value="<?php echo $item_returned['owner']?>"><?php echo $item_returned['owner']?>
									<option value="ownerA@test.com">ownerA@test.com</option>
									<option value="ownerB@test.com">ownerB@test.com</option>
									<option value="ownerC@test.com">ownerC@test.com</option>
								</select>
							</td>
						</tr>	
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Network connected to</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-network"><?php echo $item_returned['network']?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Comments</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="form-control-input" id="input-comments"><?php echo $item_returned['comments']?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Installation date</span>
							</td>
							<td class="form-group">
								<input type="text" class="form-control-input" id="input-installation-date" value="<?php echo $item_returned['installationDate']?>" readonly />
							</td>
						</tr>
					</table>
				</td> <!--Close second TD of the table-item-view-->
			</tr>
			<tr>
				<td colspan="2">
					<input type="button" value="Update item" class="update-item"><input type="button" value="Cancel" class="cancel">
				</td>
			</tr>
		</table>
		
		</div>
		<div id="main-container-view-password">
			<div class="data-content-all-credential">
				<?php
					echo $PwdContainer;
				?>
				<a href="#" class="show-add-pwd">Add pwd</a>
			</div>
			
		</div>
	</div>
</div>


<div id="main-container-add-pwd">
<div class="container-table-add-pwd">
	<table class="table-add-pwd">
	<thead>
		<h3>Add password for item: <?php echo $item_returned['name']?></h3>
	</thead>
		<tr>
			<td><span>Credential: </span></td><td><input type="text" id="new-credential"></td>
		</tr>
		<tr>
			<td><span>Password: </span></td><td><input type="text" id="new-password"></td>
		</tr>
		<tr>
			<td><span>Description: </span></td><td><input type="text" id="new-description"></td>
		</tr>
		<tr>
			<td><input type="button" class="button-add-pwd" value="Add password"></td>
			<td><input type="button" class="button-add-pwd-close" value="Close"></td>
		</tr>
	</table>
</div>
</div>


<script>

$( function() {
    $( "#input-installation-date" ).datepicker();
  } );
  
$(".update-item").click(function(){
	UpdateItem(<?php echo $q ?>); 
});

$(".cancel").click(function(){
	window.location.href = '../home.php';
})

$(".form-control-input").focus(function(){

	$(this).css("background-color", "#e5fff3");
})

$(".form-control-input").blur(function(){

	$(this).css("background-color", "white");
})
	
$( "#main-container-view-password th" ).css ("background-color", "#EEE0DD")
$( "#main-container-view-password tr:odd" ).css( "background-color", "#F0F0F0" );


$(" .show-add-pwd").click(function(){

	$("#main-container-add-pwd").fadeIn('fast');
})


$(" .button-add-pwd").click(function(){
	
	AddPwd('<?php echo $item_returned['name']?>');
})

$(" .button-add-pwd-close").click(function(){

	$("#main-container-add-pwd").fadeOut('fast');
})

</script>