<?php

include_once '../api/class.php';
 
// prepare item object
$item = new item_with_password();
 
// set item property values
$item->name = $_POST['name'];
$item->credential = $_POST['credential'];
 
 
// remove the item
if($item->deletePwd()){
    $item_arr=array(
        "status" => true,
        "message" => "Successfully Removed!"
    );
}
else{
    $item_arr=array(
        "status" => false,
        "message" => "Item cannot be deleted."
    );
}
print_r(json_encode($item_arr));
?>