<?php
// include object files
include_once '../api/class.php';


$item2add = new item();

//echo ("e siamo nel read");
 
// query hw list
$result = $item2add->ReadAllItem();

 
    // hw array
    $hw_arr=array();
    $hw_arr["item"]=array();
 
    while ($row = mysqli_fetch_array($result)){
        extract($row);
        $item=array(
            "id" => $id,
            "name" => $name,
            "state" => $state,
            "purpose" => $purpose,
            "location" => $location,
			"platform" => $os,
            "type" => $type,
            "ipaddress" => $ipaddress,
            "version" => $version,
			"owner" => $owner,
			"network" => $network,
        );
        array_push($hw_arr["item"], $item);
    }
 
    echo json_encode($hw_arr["item"]);


?>