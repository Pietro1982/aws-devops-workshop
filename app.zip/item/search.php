<?php
include_once '../api/class.php';
//get the item parameter from GET

$item2search = new item();

$q = $_GET['text2search'];


if($q=="")
{
	$data =array(
  
		"status" => false,
       
        );
		
	print_r(json_encode($data));
}

$conn =  mysqli_connect("localhost", "root", "", "test");
	// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
// select all query
$sql = 'SELECT * FROM hwlist where name LIKE "%'.$q.'%" or state LIKE "%'.$q.'%" or purpose LIKE "%'.$q.'%" or location LIKE "%'.$q.'%" or os LIKE "%'.$q.'%" or power LIKE "%'.$q.'%" or storage LIKE "%'.$q.'%" or digiport LIKE "%'.$q.'%"
		or name_alias LIKE "%'.$q.'%" or type LIKE "%'.$q.'%" or ipaddress LIKE "%'.$q.'%" or severity LIKE "%'.$q.'%" or version LIKE "%'.$q.'%" or owner LIKE "%'.$q.'%" or network LIKE "%'.$q.'%" or comment LIKE "%'.$q.'%" or installation_date LIKE "%'.$q.'%"';

if ($result = mysqli_query($conn, $sql)) 
{
	$hw_arr=array();
    $hw_arr["item"]=array();
	
	
    while ($row = mysqli_fetch_array($result)){
        extract($row);
        $item=array(
            "id" => $id,
            "name" => $name,
            "state" => $state,
            "purpose" => $purpose,
            "location" => $location,
			"platform" => $os,
            "type" => $type,
            "ipaddress" => $ipaddress,
            "version" => $version,
			"owner" => $owner,
			"network" => $network,
			"status" => true,
        );
		
		array_push($hw_arr["item"], $item);

    }
	
	if(empty($item))
	{
		$item=array(
            
            "status" => false,
        );
		print_r (json_encode($item));
		//echo ("e vuoto");
	}
	else
	{
		echo json_encode($hw_arr["item"]);
		//echo ("non � vuoto");
	}
	
	//echo 'ci siamo';
    //echo json_encode($hw_arr["item"]);
}
	
?>

