
<?php

include_once '../api/class.php';
$q = $_GET['id'];

$item = new item_with_password();

$result = $item->readItem($q);

while ($view = mysqli_fetch_array($result)){
	extract($view);
	$item_returned = array(
		"id" => $id,
		"name" => $name,
		"state" => $state,
		"purpose" => $purpose,
		"location" => $location,
		"platform" => $os,
		"power" => $power,
		"storage" => $storage,
		"digiport" => $digiport,
		"hostname-alias" => $name_alias,
		"type" => $type,
		"ipaddress" => $ipaddress,
		"severity" => $severity,
		"version" => $version,
		"owner" => $owner,
		"network" => $network,
		"comments" => $comment,
		"installationDate" => $installation_date,
		"creationDate" => $creation_date,
		"creator" => $user_creator,
		"lastUpdateDate" => $last_update_date,
		"lastUpdateUser" => $last_update_user,
	);
};

//Check if hte item has password. If so, prepare the content

	if($result = $item->readallpwd($item_returned['name']))
	{
		$AllCredential = ($result[0]);
		$AllPassword = ($result[1]);
		$AllDescription = ($result[2]);
		$PwdContainer = "<table class='table-view-item-password-container'><thead><th>System Credential</th><th>System Password</th><th>System Description</th></thead>";
		$i = 0;
		foreach($AllCredential as $credential)
		{
			$PwdContainer .= '<tr><td><span class="view-item-credential">'. $credential . '</span></td><td><a href="#" id="ShowPassword'. $i .'" class="view-item-password" onClick="ShowPassword(\''. $item_returned['name'] .'\',\''. $credential .'\',\''. $item_returned['owner'] .'\');" >Show password</a></td><td><span class="view-item-description">'. $AllDescription[$i]. '</span></td></tr>';
			$i = $i+1;
		}
		$PwdContainer .= '</table>';
	}
	if(empty($AllCredential))
	{
		$PwdContainer = "<table class='table-view-item-password-container'><thead><th>System Credential</th><th>System Password</th><th>System Description</th></thead>";
		$PwdContainer .= '<tr><td colspan="3" class="view-item-password-no-credential">No credential created yet</td>';
		$PwdContainer .= '</table>';
	}

?>

<script src="../sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="../sweetalert2.min.css">
<script src="../js/jquery.js"></script>
<script src="../js/functions.js"></script>
<link rel="stylesheet" type="text/css" href="../css/stylesheet.css">


<div id="wrapper">
	<div id="header-content">
		<div id="header-title-content"><a class="header-main-title" href="../home.php"><header>EMEA IT Hardware List</header></a></div>
	</div>
	<div id="menu">
	<div id="user-info">
		<img src="../img/avatar.png" class="img-circle">
		<span class="username">EMEA\<?php echo getenv('USERNAME')?></span>
	</div>
	<div id="search-form-content">
		<ul class="ul-menu-search">
			<li class="li-menu-search"><input type="text" placeholder="Search..." id="search-form" onFocus="searchformfocus(this);"></li>
			<li class="li-menu-search"><a href="#" onClick="searchItemFromView();"><img src="../img/search.png" id="search-button"/></a></li>
		</ul>
	</div>
	<div id="submenu">
		<ul class="ul-menu-nav">
			<li class="li-menu-nav"><a href="../item/create.php">Create Item</a></li>
			<li class="li-menu-nav">Multiple edit</li>
		</ul>
	</div>
	</div>
	
	<!--End of menu div, on left side-->
	
	<div id="data-content">
		<div id="dashboard-title"><h1><a href="../home.php" class="img-back"><img src="../img/back.png"/></a>EMEA IT Hardware List<small> > View item</small></h1></div>
		<div id="table-container-view-item">
		<h3 class="title-view-item">Details item: <?php echo (strtoupper ($item_returned['name']) ); ?> <a class="edit-item-from-view" href="update.php?id=<?php echo $item_returned['id']?>">Edit Item</a></h3>
		<span class="create-update-information">Item created on: <?php echo $item_returned['creationDate']?>, by: <?php echo $item_returned['creator']?></span>
		<br>
		<span class="create-update-information">Last update on: <?php echo $item_returned['lastUpdateDate']?>, by: <?php echo $item_returned['lastUpdateUser']?></span>
		<br>
		<br>
		<table class="main-table-item-view">
			<tr>
				<td>
					<table class="table-item-view-data-content-left">
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Name</span>
							</td>
							<td class="form-group">
								<span class="view-item-returned"><?php echo (strtoupper ($item_returned['name']) ); ?></span>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">State</span>
							</td>
							<td class="form-group">
									<select class="view-item-returned" id="input-state">
										<option value="<?php $item_returned['state'] ?>" readonly ><?php echo $item_returned['state'] ?></option>
									</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Purpose</span>
							</td>
							<td class="form-group">
								<span class="view-item-returned"><?php echo $item_returned['purpose']; ?></span>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Location</span>
							</td>
							<td class="form-group">
								<select class="view-item-returned" id="input-location">
									<option value="<?php echo $item_returned['location']; ?>" readonly><?php echo $item_returned['location']; ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Platform</span>
							</td>
							<td class="form-group">
								<select class="view-item-returned" id="input-platform">
									<option value="<?php echo $item_returned['platform']; ?>" readonly><?php echo $item_returned['platform']; ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Power connected to</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="view-item-returned" id="input-power" readonly><?php echo $item_returned['power']; ?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Storage connected to</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="view-item-returned" id="input-storage" readonly><?php echo $item_returned['storage']; ?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Digiport/RM</span>
							</td>
							<td class="form-group">
								<span class="view-item-returned"><?php echo $item_returned['digiport']; ?></span>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Hostname-alias</span>
							</td>
							<td class="form-group">
								<textarea rows="4" class="view-item-returned" cols="50" id="input-alias" readonly><?php echo $item_returned['hostname-alias']; ?></textarea>
							</td>
						</tr>
					</table>
				</td> <!--Close first TD of the table-item-view-->
				
				<td> <!--Open second TD of the table-item-view-->
					<table class="table-item-view-data-content-right">
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Type</span>
							</td>
							<td class="form-group">
								<select class="view-item-returned" id="input-type">
									<option value="<?php echo $item_returned['type']; ?>" readonly><?php echo $item_returned['type']; ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Ip Address</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="view-item-returned" id="input-ipaddress" readonly><?php echo $item_returned['ipaddress']; ?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Severity</span>
							</td>
							<td class="form-group">
								<select class="view-item-returned" id="input-severity">
									<option value="<?php echo $item_returned['severity']; ?> " readonly><?php echo $item_returned['severity']; ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Version</span>
							</td>
							<td class="form-group">
								<span class="view-item-returned"><?php echo $item_returned['version']; ?></span>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Owner</span>
							</td>
							<td class="form-group">
								<select class="view-item-returned" id="input-owner">
									<option value="<?php echo $item_returned['owner']; ?>" readonly><?php echo $item_returned['owner']; ?></option>
								</select>
							</td>
						</tr>	
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Network connected to</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="view-item-returned" id="input-network" readonly><?php echo $item_returned['network']; ?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Comments</span>
							</td>
							<td class="form-group">
								<textarea rows="4" cols="50" class="view-item-returned" id="input-comments" readonly><?php echo $item_returned['comments']; ?></textarea>
							</td>
						</tr>
						<tr>
							<td class="form-group form-control-title">
								<span class="form-control">Installation date</span>
							</td>
							<td class="form-group">
								<span class="view-item-returned"><?php echo $item_returned['installationDate']; ?></span>
							</td>
						</tr>
					</table>
				</td> <!--Close second TD of the table-item-view-->
			</tr>
		</table>
		
		</div>
		<div id="main-container-view-password">
			<div class="data-content-all-credential">
				<?php
					echo $PwdContainer;
				?>
			</div>
		</div>
	</div>

</div>


<script>
	
$( "#main-container-view-password th" ).css ("background-color", "#EEE0DD")
$( "#main-container-view-password tr:odd" ).css( "background-color", "#F0F0F0" );

</script>

