<script src="sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="sweetalert2.min.css">
<script src="js/jquery.js"></script>
<script src="js/functions.js"></script>
<link rel="stylesheet" type="text/css" href="css/stylesheet.css">


<div id="wrapper">
	<div id="header-content">
		<div id="header-title-content"><a class="header-main-title" href="home.php"><header>EMEA IT Hardware List</header></a></div>
	</div>
	<div id="menu">
	<div id="user-info">
		<img src="img/avatar.png" class="img-circle">
		<span class="username">EMEA\<?php echo getenv('USERNAME')?></span>
	</div>
	<div id="search-form-content">
		<ul class="ul-menu-search">
			<li class="li-menu-search"><input type="text" placeholder="Search..." id="search-form" onFocus="searchformfocus(this);"></li>
			<li class="li-menu-search"><a href="#" onClick="searchItem();"><img src="img/search.png" id="search-button"/></a></li>
		</ul>
	</div>
	<div id="submenu">
		<ul class="ul-menu-nav">
			<li class="li-menu-nav"><a href="item/create.php">Create Item</a></li>
			<li class="li-menu-nav">Multiple edit</li>
		</ul>
	</div>
	</div>
	
	<!--End of menu div, on left side-->
	
	<div id="data-content">
		<div id="dashboard-title"><h1>EMEA IT Hardware List<small> > Dashboard</small></h1></div>
		<div id="table-container">
		<h3>Here goes a subtitle</h3>
		<div id="table-container-smooth">
		<table id="table-item">
			<thead>
					<tr>
                        <th>Name</th>
                        <th>State</th>
                        <th>Purpose</th>
                        <th>Location</th>
                        <th>Platform</th>
                        <th>Type</th>
						<th>Ip Address</th>
						<th>Version</th>
						<th>Owner</th>
					</tr>
			</thead>
		</table>
		</div>
		</div>
	</div>
</div>

<footer id="footer">Questo e il footer</footer>


<script>

$(document).ready(function(){
    
	$.ajax({
		
		type: "GET",
		url: './item/ReadAllItem.php',
		dataType: 'json',
		
		error: function (valore_di_ritorno) {
			
			alert(valore_di_ritorno.responseText);
		},
        success: function(data) {

            var response="";
            for(var item in data){
                response += "<tr>"+
                "<td><a href='item/viewItem.php?id="+data[item].id+"' class='viewItem' title='View details' >"+data[item].name.toUpperCase()+"</a></td>"+
                "<td>"+data[item].state+"</td>"+
                "<td>"+data[item].purpose+"</td>"+
                "<td>"+data[item].location+"</td>"+
                "<td>"+data[item].platform+"</td>"+
				"<td>"+data[item].type+"</td>"+
				"<td>"+data[item].ipaddress+"</td>"+
				"<td>"+data[item].version+"</td>"+
				"<td>"+data[item].owner+"</td>"+
				"<td class='icon-control'><a class='item-icon' title='Edit Item' href='item/update.php?id="+data[item].id+"'><img src='img/edit-item.png'></a><a class='item-icon' title='Delete Item' href='#' onClick=Remove('"+data[item].id+"','"+data[item].name+"')><img src='img/delete-item.png'></a></td>"+
                "</tr>";
            }
            $(response).appendTo($("#table-item"));
			$( "th" ).css ("background-color", "#C1E3F0")
			$( "tr:odd" ).css( "background-color", "#F0F0F0" );
			$( "tr:even" ).css( "background-color", "#fff" );
        }
    });
  });


</script>



