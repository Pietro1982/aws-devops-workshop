<?php
 
include_once 'class.php';

// prepare item object
$item = new item_with_password();
 
 $name = trim($_POST['name']);
 
// set item property values
$item->name = $name;
$item->state = $_POST['state'];
$item->purpose = $_POST['purpose'];
$item->location = $_POST['location'];
$item->os = $_POST['platform'];
$item->power = $_POST['power'];
$item->storage = $_POST['storage'];
$item->digiport = $_POST['digiport'];
$item->name_alias = $_POST['hostnameAlias'];
$item->type = $_POST['type'];
$item->ipaddress = $_POST['ipaddress'];
$item->severity = $_POST['severity'];
$item->version = $_POST['version'];
$item->owner = $_POST['owner'];
$item->network = $_POST['network'];
$item->comment = $_POST['comments'];
$item->installation_date = $_POST['installationDate'];
$item->creation_date = date("d-m-Y");
$item->user_creator = getenv('USERNAME');
$item->last_update_date = date("d-m-Y");
$item->last_update_user = getenv('USERNAME');

if(!empty($_POST['credential']))
{
$item->credential = $_POST['credential'];
$item->pwd = $_POST['password'];
$item->description = $_POST['otherInfo'];
}

// create the item
if($item->create()){

	if(!empty($item->credential)){
	
		if($item->Addpwd()){
		
		$item_arr=array(
			
			"status" => true,
			);
		}
		
		else{
		
		$item_arr=array(
			
			"status" => false,
			);
		};
	}
	else{
		
		$item_arr=array(
			
			"status" => false,
			);
	};
}

else{
    $item_arr=array(
		
        "status" => false,
    );
}
print_r(json_encode($item_arr));
?>