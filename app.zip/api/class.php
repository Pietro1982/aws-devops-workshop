<?php


class item{

    // object properties
	
	public $id;
    public $name;
	public $state;
	public $purpose;
    public $location;
	public $os;
	public $power;
	public $storage;
	public $digiport;
	public $name_alias;
	public $type;
	public $ipaddress;
	public $severity;
	public $version;
	public $owner;
	public $network;
	public $comment;
	public $installation_date;
	public $creation_date;
	public $user_creator;
	public $last_update_date;
	public $last_update_user;
	protected $table_name = "hwlist";
	private $q;

	
	function create(){
	
		// Create connection
		$conn = new mysqli("localhost", "root", "Passw0rd", "hwlist");
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}

		$sql = "INSERT INTO ".$this->table_name." (name, state, purpose, location, os, power, storage, digiport, name_alias, type, ipaddress, severity, version, owner, network, comment, installation_date, creation_date, user_creator, last_update_date, last_update_user)
		VALUES ('".$this->name."', '".$this->state."', '".$this->purpose."', '".$this->location."', '".$this->os."', '".$this->power."', '".$this->storage."', '".$this->digiport."', '".$this->name_alias."', '".$this->type."', '".$this->ipaddress."'
				, '".$this->severity."', '".$this->version."', '".$this->owner."', '".$this->network."', '".$this->comment."', '".$this->installation_date."', '".$this->creation_date."', '".$this->user_creator."', '".$this->last_update_date."', '".$this->last_update_user."')";
		//echo $sql;
		
		if (mysqli_query($conn, $sql) === true) 
		{
			//echo ("la query funzia");
			return true;
		} 
		else 
		{
			//echo ("la query nn funzia");
			return false;
		}
		$conn->close();
		
	} //end function create server
	
	
	
	 // read all servers
    function ReadAllItem(){
	
		$conn =  mysqli_connect("localhost", "root", "Passw0rd", "hwlist");
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		// select all query 
		$sql = 'SELECT * FROM hwlist ORDER BY creation_date, name ASC';
		
		if ($result = mysqli_query($conn, $sql)) 
		{
			return $result;
		}
		
		else 
		{
			return false;
		}
			
		$conn->close();
	} //end function read all servers



	function readItem($uid){
	
		//$uid = $this->id;
		
		$conn =  mysqli_connect("localhost", "root", "Passw0rd", "hwlist");
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		// select all query
		$sql = 'SELECT id, name, state, purpose, location, os, power, storage, digiport, name_alias, type, ipaddress, severity, version, owner, network, comment, installation_date, creation_date, user_creator, last_update_date, last_update_user FROM hwlist WHERE id = '.$uid.'';
		//echo $sql;
		if ($result = mysqli_query($conn, $sql)) 
		{
			return $result;
		}
		else
		{
			return false;
		}
	
	} //end function view single server

	
	
	function updateItem(){
	
		$conn =  mysqli_connect("localhost", "root", "Passw0rd", "hwlist");
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		// select all query
		
		$sql = 'UPDATE ' .$this->table_name. ' SET name = "' .$this->name. '", state = "' .$this->state. '", purpose = "' .$this->purpose. '", location = "' .$this->location. '", os = "' .$this->os. '", power = "' .$this->power. '", storage = "' .$this->storage. '", digiport = "' .$this->digiport. '", name_alias  = "' .$this->name_alias. '", type = "' .$this->type. '", ipaddress = "' .$this->ipaddress. '", severity = "' .$this->severity. '", version = "' .$this->version. '", owner = "' .$this->owner. '", comment = "' .$this->comment. '", installation_date = "' .$this->installation_date. '", last_update_date = "' .$this->last_update_date. '", last_update_user = "' .$this->last_update_user. '" WHERE id = '.$this->id.'' ;
		//echo $sql;
		
		if ($conn->query($sql) === true) 
		{
			return true;
		} 
		else 
		{
			//echo ("la query nn funzia");
			return false;
		}
			
		$conn->close();
} //end function updateItem
	
	
	
	
} //end class ITEM



Class item_with_password extends item{
	
	public $credential;
	public $pwd;
	public $description;
	private $table_name_password = 'hwpassword';

	


	function Addpwd() {
	
		// Create connection
		$conn = new mysqli("localhost", "root", "Passw0rd", "hwlist");
		
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		
		$sql = "INSERT INTO ".$this->table_name_password." (name, credential, pwd, description)
		VALUES ('".$this->name."', '".$this->credential."', '".$this->pwd."', '".$this->description."')";
		
		if ($conn->query($sql) === true) 
		{
			return true;
		} 
		else 
		{
			echo ("la query nn funzia");
			return false;
		}
			
		$conn->close();
		
} //end function Addpwd


	function readallpwd($itemName) {
	
		// Create connection
		$conn = new mysqli("localhost", "root", "Passw0rd", "hwlist");
		
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		
		$sql = 'SELECT * FROM hwpassword WHERE name ="'.$itemName.'"';
		
		//echo $sql;
		
		if ($result = mysqli_query($conn, $sql)) 
		{
		$item_cred = array();
		$item_pwd = array();
		$item_descr = array();
		while(	$row = mysqli_fetch_assoc($result)){
				
				array_push($item_cred,$row['credential']);
				array_push($item_pwd,$row['pwd']);
				array_push($item_descr,$row['description']);
				//print_r ($row);	
				}
				return array($item_cred,$item_pwd,$item_descr);
		} 
		else 
		{
			return false;
			echo 'nn ci siamo,query andata a male';
		}
			
		$conn->close();
			
	} //end function readllpwd
	
	
	
	
	function ReadSinglePwd($itemName, $credential){
		
		// Create connection
		$conn = new mysqli("localhost", "root", "Passw0rd", "hwlist");
		
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		
		$sql = 'SELECT * FROM hwpassword WHERE name ="'.$itemName.'" AND credential ="'.$credential.'"';
		//echo $sql;
		
		if($result = mysqli_query($conn, $sql)) 
			{
				return $result;
			}
	
	} //end function ReadSinglePwd
	
	
	
	
	
		function delete(){
        
		$conn =  mysqli_connect("localhost", "root", "Passw0rd", "hwlist");
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
        // query to delete record
        $sqlItem = "DELETE FROM " . $this->table_name . " WHERE id= '".$this->id."'";
		$sqlItemPassword = "DELETE FROM " . $this->table_name_password . " WHERE name= '".$this->name."'";

        if (mysqli_query($conn, $sqlItem)) 
		{
			if(mysqli_query($conn, $sqlItemPassword)) 
			{
				return true;
			}
		}
        
		return false;

	} //end function Delete
	
	
	function deletePwd(){
        
		$conn =  mysqli_connect("localhost", "root", "Passw0rd", "hwlist");
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
        // query to delete record
        
		$sqlItemPassword = "DELETE FROM " . $this->table_name_password . " WHERE name= '".$this->name."' AND credential = '".$this->credential."'";

        if (mysqli_query($conn, $sqlItemPassword)) 
		{
			return true;
		}
        
		return false;

	} //end function deletePwd

} //end class hwpassword

?>