<?php
 
include_once 'class.php';

// prepare item object
$item = new item_with_password();
 

 
// set item property values
$item->name = $_POST['name'];

if(!empty($_POST['credential']))
{
	$item->credential = $_POST['credential'];
	$item->pwd = $_POST['password'];
	$item->description = $_POST['otherInfo'];
	// create the new credential
	if($item->AddPwd()){

		$item_arr=array(
			
			"status" => true,
		);
		
	}

	else{
		$item_arr=array(
			
			"status" => false,
		);
	}
}

else
{
	$item_arr=array(
			
			"status" => false,
	);
	
}


print_r(json_encode($item_arr));
?>