
function search_item() {
	
	var testo = document.getElementById('search_text').value;
	
	$.ajax(
        {	
            type: "POST",
            url: 'suggest.php',
            dataType: 'json',
            data: {
                q: testo,

            },
            error: function (valore_di_ritorno) {
                //alert(valore_di_ritorno.responseText);
					document.getElementById("livesearch").innerHTML = 'No suggestion';
            },
            success: function (valore_di_ritorno) {
                if (valore_di_ritorno['status'] == true) {
				
                    var returned_name = valore_di_ritorno['name'];
					var returned_id = valore_di_ritorno['id'];
					var i;
					var search_result='';
					for (i=0; i<returned_name.length; i++) {
										
						search_result += ('<span><a href="#" class="aclass" onclick="read_single('+returned_id[i]+')";>' +returned_name[i] + '</a><span><br>');
						
					}
					
					document.getElementById("livesearch").innerHTML = search_result;
					//document.getElementById("pippo").style.display = "block";
					var x = document.getElementById("livesearch");
					var y = x.getElementsByClassName("aclass");
					var i;
					for (i = 0; i < y.length; i++) {
					  y[i].style.color = "#444";
					  y[i].style.fontSize='20px';
					  y[i].style.textDecoration='underline';
					  y[i].onmouseover = function (){this.style.color='#ffa500'};
					  y[i].onmouseout = function (){this.style.color='#444'};
					}
                }
                else {
                    alert(valore_di_ritorno['message']);
                }
            }
        });
}
	
	
	
function read_single(uid){
	
	$.ajax(
        {	
            type: "POST",
            url: 'read_single_server.php',
            dataType: 'json',
            data: {
                id: uid,

            },
            error: function (valore_di_ritorno) {
                alert(valore_di_ritorno.responseText);
            },
            success: function (valore_di_ritorno) {
                if (valore_di_ritorno['status'] == true) {
                    
					document.getElementById("name_inner").value =(valore_di_ritorno['name']);
					$('#name_inner').prop('disabled', true);
					document.getElementById("state_inner").value =(valore_di_ritorno['state']);
					$('#state_inner').prop('disabled', true);
					document.getElementById("purpose_inner").value =(valore_di_ritorno['purpose']);
					$('#purpose_inner').prop('disabled', true);
					document.getElementById("location_inner").value =(valore_di_ritorno['location']);
					$('#location_inner').prop('disabled', true);
					document.getElementById("os_inner").value =(valore_di_ritorno['os']);
					$('#os_inner').prop('disabled', true);
					document.getElementById("power_inner").value =(valore_di_ritorno['power']);
					$('#power_inner').prop('disabled', true);
					document.getElementById("storage_inner").value =(valore_di_ritorno['storage']);
					$('#storage_inner').prop('disabled', true);
					document.getElementById("digiport_inner").value =(valore_di_ritorno['digiport']);
					$('#digiport_inner').prop('disabled', true);
					document.getElementById("name_alias_inner").value =(valore_di_ritorno['name_alias']);
					$('#name_alias_inner').prop('disabled', true);
					document.getElementById("type_inner").value =(valore_di_ritorno['type']);
					$('#type_inner').prop('disabled', true);
					document.getElementById("ipaddress_inner").value =(valore_di_ritorno['ipaddress']);
					$('#ipaddress_inner').prop('disabled', true);
					document.getElementById("severity_inner").value =(valore_di_ritorno['severity']);
					$('#severity_inner').prop('disabled', true);
					document.getElementById("version_inner").value =(valore_di_ritorno['version']);
					$('#version_inner').prop('disabled', true);
					document.getElementById("owner_inner").value =(valore_di_ritorno['owner']);
					$('#owner_inner').prop('disabled', true);
					document.getElementById("network_inner").value =(valore_di_ritorno['network']);
					$('#network_inner').prop('disabled', true);
					document.getElementById("comment_inner").value =(valore_di_ritorno['comment']);
					$('#comment_inner').prop('disabled', true);
					document.getElementById("installation_date_inner").value =(valore_di_ritorno['installation_date']);
					$('#installation_date_inner').prop('disabled', true);
					$("#view-item-form").fadeIn('fast');
					$("#livesearch").empty();
					
                    //window.location.href = 'home.php';
					
                }
                else {
                    alert(valore_di_ritorno['message']);
					alert('nn va ancora');
                }
            }
        });
	
	
	}
	

	
function CloseData(DivID){
	
	document.getElementById(DivID).style.display = "none";		
}



 function show_add_item(){
	
	$("#add-item-form").fadeIn('fast');
}	



  function AddItem(){
  
        $.ajax(
        {
            type: "POST",
            url: 'new_item.php',
            dataType: 'json',
            data: {
			
                name: $("#name").val(),
				state: $("#state").val(),
                purpose: $("#purpose").val(),
				location: $("#location").val(),
                os: $("#os").val(),
				power: $("#power").val(),
				storage: $("#storage").val(),
				digiport: $("#digiport").val(),
				name_alias: $("#name_alias").val(),
				type: $("#type").val(),
				ipaddress: $("#ipaddress").val(),
				severity: $("#severity").val(),
				version: $("#version").val(),
				owner: $("#owner").val(),
				network: $("#network").val(),
				comment: $("#comment").val(),
				installation_date: $("#installation_date").val(),
            },
            error: function (result) {
				alert('nn va');
                alert(result.responseText);
            },
            success: function (result) {
                if (result['status'] == true) {
                    alert("Successfully Added New Item!");
                    window.location.href = "home.php";
                }
                else {
					alert('siamo nell else');
                    alert(result['message']);
                }
            }
        });
} 



function addpwd() {

	$.ajax(
        {
            type: "POST",
            url: 'addpwd.php',
            dataType: 'json',
            data: {
			
               
				name: $("#name_inner").val(),
				credential: $("#system-credential").val(),
				pwd: $("#system-pwd").val(),
				description: $("#system-description").val(),
				
            },
            error: function (result) {
				alert('nn va piu');
                alert(result.responseText);
            },
            success: function (result) {
                if (result['status'] == true) {
                    alert("Successfully Added New Pwd!");
					$("#system-credential").val('');
					$("#system-pwd").val('');
					$("#system-description").val('');
					CloseData("show-add-pwd");
                    window.location.href = "#";
                }
                else {
					alert('siamo nell else');
                    alert(result['message']);
                }
            }
        });
}



function showpassword() {
		
		$.ajax(
        {
            type: "POST",
            url: 'readallpwd.php',
            dataType: 'json',
            data: {
			
               
				name: $("#name_inner").val(),
			
				
            },
            error: function (valore_di_ritorno) {
					
					//search_result += '<h1>No password yet</h1>';
					//document.getElementById("inner-all-pwd").innerHTML = search_result;
                    //window.location.href = "#";
					
					alert('nn va lo show password');
					alert(valore_di_ritorno.responseText);
            },
            success: function (valore_di_ritorno) {
                if (valore_di_ritorno['status'] == true) {
                    //alert("funziona!!!!");
					//alert("Successfully Added New Pwd!");
					$("#show-add-pwd").slideToggle();
					
					var returned_cred = valore_di_ritorno['credential'];
					var returned_pwd = valore_di_ritorno['pwd'];
					var returned_cred_to_array = Object.values(returned_cred);
					var returned_pwd_to_array = Object.values(returned_pwd);
					var arrayLength = returned_cred_to_array.length;
					var i;
					var search_result='<table style="broder:1px solid black;">';
					for (i=0; i<arrayLength; i++) {
										
						search_result += ('<tr><td>'+returned_cred_to_array[i]+'</td><td><a href="#" onClick="show_pwd_reason();">Show password</a></td></tr><br>');
						
					}
					search_result += '</table>';
					document.getElementById("inner-all-pwd").innerHTML = search_result;
                    window.location.href = "#";
                }
                else {
					
					alert('siamo nell else');
                    alert(result['message']);
                }
            }
        });
}

function show_pwd_reason() {

	$("#layer-show-pwd-reason").fadeIn('fast');

}